#!/bin/bash

NFS_SERVER="172.31.3.38"
NFS_PATH="/srv/nfs"

helm repo add nfs-subdir-external-provisioner \
  https://kubernetes-sigs.github.io/nfs-subdir-external-provisioner/

helm repo update

helm install nfs-subdir-external-provisioner \
  nfs-subdir-external-provisioner/nfs-subdir-external-provisioner \
  --set nfs.server=${NFS_SERVER} \
  --set nfs.path=${NFS_PATH}
