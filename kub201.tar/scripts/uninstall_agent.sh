#!/bin/bash

K8S_DISTRO="rke2"
NODE_TYPE="agent"

cp /etc/rancher/${K8S_DISTRO}/config.yaml ~/config.yaml.backup-$(date +%s)

systemctl disable --now ${K8S_DISTRO}-${NODE_TYPE}.service

${K8S_DISTRO}-killall.sh
${K8S_DISTRO}-uninstall.sh

