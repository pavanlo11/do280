#!/bin/bash

if [ -z ${1} ]
then
  echo
  echo "ERROR: You must supply a username."
  echo
  echo "USAGE: ${1} <username> [<namespace>]"
  echo
  exit
else
 KUBE_USER=${1}
fi

if [ -z ${2} ]
then
  NAMESPACE=default
else
  if kubectl get namespace | grep -q ${2}
  then
    NAMESPACE=${2}
  else
    echo
    echo "ERROR: The supplied namespace doesn't appear to exist. Exiting."
    echo
    exit
  fi
fi

CA_DATA=$(kubectl config view --flatten --minify | grep 'certificate-authority-data:' | awk '{ print $2 }')
SERVER=$(kubectl config view --flatten --minify | grep 'server:' | awk '{ print $2 }')
CLUSTER_NAME=$(kubectl config view --flatten --minify | grep 'name:' | head -1 | awk '{ print $2 }')
USER_SECRET=$(kubectl describe serviceaccounts -n ${NAMESPACE} ${KUBE_USER} | grep Tokens: | awk '{ print $2 }')
USER_TOKEN=$(kubectl describe secrets -n ${NAMESPACE} ${USER_SECRET} | grep token:  | awk '{ print $2 }')

echo "
apiVersion: v1
kind: Config
clusters:
- cluster:
    certificate-authority-data: ${CA_DATA} 
    server: ${SERVER} 
  name: ${CLUSTER_NAME} 
contexts:
- context:
    cluster: ${CLUSTER_NAME} 
    user: ${KUBE_USER} 
  name: ${CLUSTER_NAME} 
current-context: ${CLUSTER_NAME} 
users:
- name: ${KUBE_USER} 
  user: 
    token: ${USER_TOKEN} 
" > kubeconf-${KUBE_USER}
