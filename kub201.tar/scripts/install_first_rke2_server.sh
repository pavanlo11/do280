#!/bin/bash

###########  Begin - Edit for your cluster/node ############

# Cluster to install (used in token)
#
CLUSTER="cluster01"

# RKE2 channel to use (overrides RKE2_VER)
#
RKE2_CHANNEL="v1.25"

# RKE2 version to use (overridden by RKE2_CHANNEL)
#
RKE2_VER="v1.25.6"

# Node type to install (server, agent)
#
NODE_TYPE="server"

###########  End - Edit for your cluster ############

K8S_DISTRO="rke2"
RKE2_ARTIFACTS="~/${K8S_DISTRO}_install/${RKE2_VER}"

#----- Get Install Script -----
if [ -e ${RKE2_ARTIFACTS}/install.sh ]
then
  chmod +x ${RKE2_ARTIFACTS}/install.sh
  INSTALL_SCRIPT="${RKE2_ARTIFACTS}/install.sh"
elif ! [ -e install.sh ]
then
  curl -sfL https://get.${K8S_DISTRO}.io --output install.sh
  chmod +x install.sh
  INSTALL_SCRIPT="./install.sh"
else
  INSTALL_SCRIPT="./install.sh"
fi

#----- Create config.yaml -----
if ! [ -e /etc/rancher/${K8S_DISTRO} ]
then
  mkdir -p /etc/rancher/${K8S_DISTRO}
fi
  
if [ -e ./config.yaml ]
then
  cp ./config.yaml /etc/rancher/${K8S_DISTRO}
else
  echo "token: my${K8S_DISTRO}${CLUSTER}" >> ./config.yaml
  echo "tls-san:" >> ./config.yaml
  echo "  - ${CLUSTER}.example.com" >> ./config.yaml
  echo "cni: canal" >> ./config.yaml
  cp ./config.yaml /etc/rancher/${K8S_DISTRO}/
fi

#----- Enable Longhorn if Present -----
if [ -e ./longhorn.yaml ]
then
  if ! [ -e /var/lib/rancher/${K8S_DISTRO}/server/manifests ]
  then
    mkdir -p /var/lib/rancher/${K8S_DISTRO}/server/manifests
  fi

  cp longhorn*.yaml /var/lib/rancher/${K8S_DISTRO}/server/manifests/
fi

#----- Install K8s Distro -----
if ! [ -z ${RKE2_CHANNEL} ]
then
  echo "INSTALL_RKE2_TYPE=${NODE_TYPE} INSTALL_RKE2_CHANNEL=${RKE2_CHANNEL} ${INSTALL_SCRIPT}"
  INSTALL_RKE2_TYPE=${NODE_TYPE} INSTALL_RKE2_CHANNEL=${RKE2_CHANNEL} ${INSTALL_SCRIPT}
elif [ -e ${RKE2_ARTIFACTS} ]
then
  echo "INSTALL_RKE2_TYPE=${NODE_TYPE} INSTALL_RKE2_ARTIFACT_PATH=${RKE2_ARTIFACTS} ${INSTALL_SCRIPT}"
  INSTALL_RKE2_TYPE=${NODE_TYPE} INSTALL_RKE2_ARTIFACT_PATH=${RKE2_ARTIFACTS} ${INSTALL_SCRIPT}
else
  echo "INSTALL_RKE2_TYPE=${NODE_TYPE} INSTALL_RKE2_VERSION=${RKE2_VER} ${INSTALL_SCRIPT}"
  INSTALL_RKE2_TYPE=${NODE_TYPE} INSTALL_RKE2_VERSION=${RKE2_VER} ${INSTALL_SCRIPT}
fi

#----- Symlink kubectl and kubeconfig -----
if ! [ -e ~/.kube/config ]
then
  mkdir -p ~/.kube
  ln -s /etc/rancher/${K8S_DISTRO}/${K8S_DISTRO}.yaml ~/.kube/config
fi

if ! [ -e /usr/local/bin/kubectl ]
then
  ln -s /var/lib/rancher/${K8S_DISTRO}/bin/kubectl /usr/local/bin/
fi

#----- Enable and Start K8s Service -----
systemctl enable --now ${K8S_DISTRO}-${NODE_TYPE}.service

