#!/bin/bash

DOMAIN=example.com
NODE01=node01.${DOMAIN}
CLUSTER=cluster01

mkdir -p ~/.kube
sudo scp root@${NODE01}:/var/lib/rancher/rke2/bin/kubectl /usr/local/bin
sudo chmod +x /usr/local/bin/kubectl
scp root@${NODE01}:/etc/rancher/rke2/rke2.yaml ~/.kube/config
sed -i "s/\( .*\)server:.*/\1server: https:\/\/${CLUSTER}.${DOMAIN}:6443/" ~/.kube/config

kubectl completion bash | sudo tee /etc/bash_completion.d/kubectl > /dev/null

