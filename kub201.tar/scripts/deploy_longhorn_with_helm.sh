#!/bin/bash

K8S_DISTRO="rke2"
LH_USER="admin"
LH_PASSWORD="longhorn"
LH_URL="longhorn01.example.com"
LH_DEFAULT_REPLICA_COUNT=3
LH_ADD_DISKS="vdb vdc"

##############################################################################

case $(whoami) in
  root)
    SUDO_CMD=""
  ;;
  *)
    SUDO_CMD="sudo"
  ;;
esac

##############################################################################
# Make sure the kubeconfig and kubectl are available
##############################################################################

if ! [ -e ~/.kube/config ]
then
  mkdir -p ~/.kube
  ln -s /etc/rancher/${K8S_DISTRO}/${K8S_DISTRO}.yaml ~/.kube/config
fi

if ! [ -e /usr/local/bin/kubectl ]
then
  ln -s /var/lib/rancher/${K8S_DISTRO}/bin/kubectl /usr/local/bin/
fi


##############################################################################
# Install Longhorn with helm
##############################################################################

if [ -z ${LH_URL} ]
then
  LH_URL="$(hostname -f)"
fi

echo "
defaultSettings:
  defaultReplicaCount: ${LH_DEFAULT_REPLICA_COUNT}
" > longhorn-values.yaml

helm repo add longhorn https://charts.longhorn.io
helm repo update

helm install longhorn longhorn/longhorn --namespace longhorn-system --create-namespace -f longhorn-values.yaml


##############################################################################
# Create the ingress for Longhorn
##############################################################################

echo "${LH_USER}:$(openssl passwd -stdin -apr1 <<< ${LH_PASSWORD})" >> auth

kubectl -n longhorn-system create secret generic longhorn-auth --from-file=auth

echo "
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: longhorn-ingress
  namespace: longhorn-system
  annotations:
    # type of authentication
    nginx.ingress.kubernetes.io/auth-type: basic
    # prevent the controller from redirecting (308) to HTTPS
    nginx.ingress.kubernetes.io/ssl-redirect: 'false'
    # name of the secret that contains the user/password definitions
    nginx.ingress.kubernetes.io/auth-secret: longhorn-auth
    # message to display with an appropriate context why the authentication is required
    nginx.ingress.kubernetes.io/auth-realm: 'Authentication Required '
    # custom max body size for file uploading like backing image uploading
    nginx.ingress.kubernetes.io/proxy-body-size: 10000m
spec:
  rules:
  - host: "${LH_URL}"
    http:
      paths:
      - pathType: Prefix
        path: "/"
        backend:
          service:
            name: longhorn-frontend
            port:
              number: 80
" > longhorn-ingress.yaml
 
kubectl -n longhorn-system create -f longhorn-ingress.yaml



##############################################################################
# Mount up additional disks for use with Longhorn
##############################################################################

if ! [ -z "${LH_ADD_DISKS}" ]
then
  for DISK in ${LH_ADD_DISKS}
  do
    ${SUDO_CMD} mkdir -p /longhorn_disks/${DISK}
    ${SUDO_CMD} mkfs.ext4 /dev/${DISK}
    ${SUDO_CMD} echo "/dev/${DISK}  /longhorn_disks/${DISK}  ext4  defaults  0  0" >> /etc/fstab
    ${SUDO_CMD} mount /dev/${DISK}
  done
fi

